export class Player {

    loginName?: string;
    playerId: string;
    playerName?: string;
    password?: string
    socketId?: string;
    activeRoomId?: string;
    gameHistory?: string[];
}

