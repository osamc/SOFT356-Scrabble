export class Message {

    contents: string;
    from: string;

}

